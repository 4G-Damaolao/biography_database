<?php 
    $dbServername = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbName = "biography";

    $conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName); 

?>  